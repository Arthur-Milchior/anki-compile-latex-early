# "warningBox"
When should a warning box tell you when you introduce a latex error. When warning are not used, yellow box (tooltips) are used instead. Its possible values are:
* "never": i.e.  always use tooltips
* "On first error" : with this option, you'll be warned each time you introduce an error in a note. That is, if a note has no LaTeX error and you introduce one, then you'll have a warning message. However, if the note already has a LaTeX error, you won't be notified again. (This is the default)
